import 'package:flutter/material.dart';

class globalNavigatorConnect {
  static final GlobalKey<NavigatorState> navigatorState =
  GlobalKey<NavigatorState>();
}