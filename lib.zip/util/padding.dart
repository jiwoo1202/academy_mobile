import 'package:flutter/material.dart';

const EdgeInsets ph24 = EdgeInsets.symmetric(horizontal: 24);
const EdgeInsets ph20v14 = EdgeInsets.symmetric(horizontal: 20,vertical: 14);
const EdgeInsets ph24v12 = EdgeInsets.symmetric(horizontal: 24,vertical: 12);
