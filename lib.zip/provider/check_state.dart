import 'package:get/get.dart';

class CheckState extends GetxController{
  final myCheckList = [].obs;
  final listTrue = ''.obs;
  final checkQrcode = ''.obs;
  final rndList = [].obs; //
}