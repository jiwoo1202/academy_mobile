import 'package:academy/model/user.dart';
import 'package:get/get.dart';

class JobState extends GetxController{
  final answer = <String>[].obs;
  final jobDocId = ''.obs;
  final jobHasImage = ''.obs;
  final jobbody = ''.obs;
  final jobTeacher = ''.obs;
  final jobCreateDate = ''.obs;
  final realAnswer = [].obs;
  final commentId = [].obs;
  final commentBody = [].obs;
  final userL = [].obs;
  final commentL = [].obs;
  final selectJobTile = [].obs;

  final jobTitle = ''.obs; //추가
  final jobList = [].obs; //추가
  final notuserL = [].obs; //추가
  final jobTitle1 = ''.obs;
  final jobTitle2 = ''.obs;

  final jobHuntingTeacherName = ''.obs;
// final name = ''.obs;


}